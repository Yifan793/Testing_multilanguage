var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ImageViewerCommand;
(function (ImageViewerCommand_1) {
    var ImageViewerCommand = /** @class */ (function (_super) {
        __extends(ImageViewerCommand, _super);
        function ImageViewerCommand() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.initialViewIndex = 0;
            _this.originSettings = {
                bodyOriginOverflow: '',
            };
            return _this;
        }
        ImageViewerCommand.prototype.execute = function () {
            var commandParam = this.CommandParam;
            var targetCellLocation = this.getCellLocation(commandParam.TargetCell);
            if (!targetCellLocation) {
                return;
            }
            var cellId = this.getIdStr(targetCellLocation);
            var targetCellDOM = $("#".concat(cellId))[0];
            if (!targetCellDOM) {
                return;
            }
            this.init(cellId);
        };
        ImageViewerCommand.prototype.init = function (cellId) {
            this.storeOriginSetting();
            this.targetImgs = $("#".concat(cellId, " img, #").concat(cellId, " svg"));
            this.setInitialViewIndex();
            this.createPreviewer();
        };
        ImageViewerCommand.prototype.destroy = function () {
            this.destoryPreviewer();
            this.revertOriginSetting();
        };
        ImageViewerCommand.prototype.storeOriginSetting = function () {
            // 预览展示的时候，如果页面有滚动条会遮住，需要在关闭展示之后恢复原设置
            this.originSettings.bodyOriginOverflow = document.body.style.overflow;
        };
        ImageViewerCommand.prototype.revertOriginSetting = function () {
            document.body.style.overflow = this.originSettings.bodyOriginOverflow;
        };
        ImageViewerCommand.prototype.setInitialViewIndex = function () {
            if (this.targetImgs.length === 0) {
                return;
            }
            // 当前触发命令的的单元格 C，目标单元格 T：C 内的第一个 Img 的有效次序作为预览的 initialViewIndex，其余情况均取默认值 0
            var currentImg = $("#".concat(this.CommandExecutingInfo.commandId, " svg, #").concat(this.CommandExecutingInfo.commandId, " img"));
            var currentImgIndex = this.targetImgs.index(currentImg);
            if (currentImgIndex > -1 && currentImgIndex !== this.initialViewIndex) {
                this.initialViewIndex = currentImgIndex;
            }
        };
        ImageViewerCommand.prototype.createPreviewer = function () {
            this.destoryPreviewer();
            this.previewer = $("<div class=\"image-viewer-command\"></div>");
            this.previewer.append(this.createPreviewerHeader(), this.createPreviewerContent());
            document.body.style.overflow = "hidden";
            $(document.body).append(this.previewer);
            this.initClickBackdropToClosePreview();
            var activeItem = this.previewer.find(".carousel-inner .carousel-item").eq(this.initialViewIndex);
            if (activeItem.length > 0) {
                activeItem.addClass("active");
                this.lazyLoad(activeItem);
            }
        };
        ImageViewerCommand.prototype.initClickBackdropToClosePreview = function () {
            var _this = this;
            // https://grapecity.atlassian.net/browse/FORGUNCY-10686
            // Viewer.js 自身在 inline 模式下不支持点击黑屏关闭预览，而使用 inline 模式是为了支持 Slide 滑动切换
            // 为了综合需求、代码复杂度和代码扩展，采用简单策略：在显示图片的区域内，增加 click 监听事件，若不是 img 元素触发 click，则直接关闭预览
            // 若以后升级 Viewer.js 版本，建议注意此部分内容，是否会影响插件原有设计
            this.previewer.find('.carousel-inner').on('click', '.viewer-canvas', function (e) {
                if (e.target.localName === 'img') {
                    return;
                }
                _this.destroy();
                e.stopPropagation();
            });
        };
        ImageViewerCommand.prototype.destoryPreviewer = function () {
            if (!this.previewer) {
                return;
            }
            this.previewer.remove();
        };
        ImageViewerCommand.prototype.createPreviewerHeader = function () {
            var _this = this;
            var container = $("\n            <div class=\"FP-previewer-header\">\n                <span class=\"FP-header-title\" data-toggle=\"tooltip\" data-placement=\"bottom\"></span>\n                <div class=\"FP-button-close\">\n                    <svg class=\"octicon octicon-x\" viewBox=\"0 0 12 16\" version=\"1.1\" width=\"16\" height=\"16\" aria-hidden=\"true\">\n                        <path fill-rule=\"evenodd\" d=\"M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z\"></path>\n                    </svg>\n                </div>\n            </div>");
            container.find('.FP-button-close').click(function (e) {
                e.stopPropagation();
                _this.destroy();
            });
            return container;
        };
        ImageViewerCommand.prototype.createPreviewerContent = function () {
            var _this = this;
            var carouselId = "FP-carousel-" + Math.floor(Math.random() * 100000).toString();
            var isMultipleImgs = this.targetImgs.length > 1;
            var indicatorsText = "\n            <ol class=\"carousel-indicators\">".concat(this.targetImgs.map(function (index, item) {
                return "<li data-target=\"#".concat(carouselId, "\" data-slide-to=\"").concat(index, "\" class=\"").concat(_this.initialViewIndex === index ? 'active' : '', "\"></li>");
            }).toArray().join(''), "</ol>");
            var innerText = "\n            <div class=\"carousel-inner\">".concat(this.targetImgs.map(function (index, item) {
                if (item instanceof HTMLImageElement) {
                    return "<div class=\"carousel-item\" data-type data-title=\"".concat(item.src, "\" data-src=\"").concat(item.src, "\"></div>");
                }
                else if (item instanceof SVGElement) {
                    return "<div class=\"carousel-item\" data-type data-title=\"".concat($(item).parents("[imagename]").attr("imagename"), "\" data-src=\"").concat("data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(item.outerHTML))), "\"></div>");
                }
            }).toArray().join(''), "</div>");
            var prevText = "\n            <a class=\"carousel-control-prev\" href=\"#".concat(carouselId, "\" role=\"button\" data-slide=\"prev\">\n                <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>\n                <span class=\"sr-only\">Previous</span>\n            </a>");
            var nextText = "\n            <a class=\"carousel-control-next\" href=\"#".concat(carouselId, "\" role=\"button\" data-slide=\"next\">\n                <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>\n                <span class=\"sr-only\">Next</span>\n            </a>");
            var container = $("\n            <div class=\"FP-previewer-content\">\n                <div id=\"".concat(carouselId, "\" class=\"carousel slide\" data-ride=\"carousel\" data-interval=\"false\">\n                    ").concat(isMultipleImgs ? indicatorsText : '', "\n                    ").concat(innerText, "\n                    ").concat(isMultipleImgs ? prevText : '', "\n                    ").concat(isMultipleImgs ? nextText : '', "\n                </div>\n            </div>"));
            container.on("slide.bs.carousel", function (event) {
                _this.lazyLoad($(event.relatedTarget));
            });
            return container;
        };
        ImageViewerCommand.prototype.lazyLoad = function (target) {
            var src = target.attr("data-src");
            if (target.find("img").length === 0) {
                var img = $("<img class=\"d-block\" style=\"display:none !important\" src=\"".concat(src, "\" />"));
                target.append(img);
                this.createViewer(img[0]);
            }
            var title = target.attr("data-title");
            $(this.previewer).find(".FP-header-title").text(this.getDisplayTitle(title));
        };
        ImageViewerCommand.prototype.createViewer = function (targetDOM) {
            var LIMIT_CLASS_NAME = 'image-viewer-command-viewerjs';
            var QUERY_IMAGE_SIZE_NAME = 'imageSize';
            // inline: true, navbar: false, toolbar: true, title: false, button: false, backdrop: false, transition: false
            return new Viewer(targetDOM, {
                inline: true,
                title: false,
                button: false,
                backdrop: false,
                transition: false,
                url: function (image) {
                    // upload 路径下会有 QUERY_IMAGE_SIZE_NAME 条件来设置返回小、中或大图，在预览下需要移除此选项均返回大图
                    var originImageHref = decodeURI(image.src);
                    var uploadURL = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer();
                    if (originImageHref.search(uploadURL) === -1) {
                        return originImageHref;
                    }
                    var searchIndex = originImageHref.indexOf('?');
                    var hashIndex = originImageHref.indexOf('#');
                    var isHasHash = hashIndex > -1;
                    var search = isHasHash ? originImageHref.substring(searchIndex, hashIndex) : originImageHref.substring(searchIndex);
                    var querys = search.substring(1).split('&');
                    for (var i = 0, len = querys.length; i < len; i++) {
                        var queryName = querys[i].split("=")[0];
                        if (queryName === QUERY_IMAGE_SIZE_NAME) {
                            querys.splice(i, 1);
                            return "".concat(originImageHref.substring(0, searchIndex), "?").concat(querys.join('&')).concat(isHasHash ? originImageHref.substring(hashIndex) : '');
                        }
                    }
                    return originImageHref;
                },
                className: LIMIT_CLASS_NAME,
                navbar: false,
                toolbar: {
                    zoomIn: true,
                    zoomOut: true,
                    oneToOne: true,
                    reset: true,
                    prev: false,
                    play: {
                        show: false,
                        size: 'large',
                    },
                    next: false,
                    rotateLeft: true,
                    rotateRight: true,
                    flipHorizontal: true,
                    flipVertical: true
                }
            });
        };
        ImageViewerCommand.prototype.getDisplayTitle = function (src) {
            var url = decodeURIComponent(src);
            if (FileDownload.is(url)) {
                return FileDownload.getFileName(url);
            }
            else if (FileUpload.is(url)) {
                return FileUpload.getFileName(url);
            }
            else if (UploadImage.is(url)) {
                return UploadImage.getFileName(url);
            }
            else {
                return NormalBaseUrl.getFileName(url);
            }
        };
        ImageViewerCommand.prototype.getIdStr = function (cellLocation) {
            return "".concat(Forguncy.Page.getCellByLocation(cellLocation)._getCellId(), "_div");
        };
        return ImageViewerCommand;
    }(Forguncy.Plugin.CommandBase));
    ImageViewerCommand_1.ImageViewerCommand = ImageViewerCommand;
    var ServerBaseUrl = /** @class */ (function () {
        function ServerBaseUrl() {
        }
        ServerBaseUrl.getBaseUrl = function () {
            return "";
        };
        ServerBaseUrl.is = function (url) {
            return url.indexOf(this.getBaseUrl()) > -1;
        };
        ServerBaseUrl.getFileName = function (url) {
            return this.removeQuery(url);
        };
        ServerBaseUrl.removeQuery = function (url) {
            return url.indexOf("?") > -1 ? url.slice(0, url.indexOf("?")) : url;
        };
        return ServerBaseUrl;
    }());
    var NormalBaseUrl = /** @class */ (function (_super) {
        __extends(NormalBaseUrl, _super);
        function NormalBaseUrl() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        NormalBaseUrl.getFileName = function (url) {
            return _super.getFileName.call(this, url.split("/").pop());
        };
        return NormalBaseUrl;
    }(ServerBaseUrl));
    var FileDownload = /** @class */ (function (_super) {
        __extends(FileDownload, _super);
        function FileDownload() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FileDownload.getBaseUrl = function () {
            return Forguncy.Helper.SpecialPath.getBaseUrl() + "FileDownloadUpload/Download?file=";
        };
        FileDownload.getFileName = function (url) {
            return _super.getFileName.call(this, url.substring(url.indexOf(this.getBaseUrl()) + this.getBaseUrl().length + 37));
        };
        return FileDownload;
    }(ServerBaseUrl));
    var FileUpload = /** @class */ (function (_super) {
        __extends(FileUpload, _super);
        function FileUpload() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FileUpload.getBaseUrl = function () {
            return Forguncy.Helper.SpecialPath.getBaseUrl() + "FileDownloadUpload/Upload";
        };
        FileUpload.getFileName = function (url) {
            return _super.getFileName.call(this, url.substring(url.indexOf(this.getBaseUrl()) + this.getBaseUrl().length + 37));
        };
        return FileUpload;
    }(ServerBaseUrl));
    var UploadImage = /** @class */ (function (_super) {
        __extends(UploadImage, _super);
        function UploadImage() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        UploadImage.getBaseUrl = function () {
            return Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer();
        };
        UploadImage.getFileName = function (url) {
            return _super.getFileName.call(this, url.substring(url.indexOf(this.getBaseUrl()) + this.getBaseUrl().length + 37));
        };
        return UploadImage;
    }(ServerBaseUrl));
})(ImageViewerCommand || (ImageViewerCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("ImageViewerCommand.ImageViewerCommand, ImageViewerCommand", ImageViewerCommand.ImageViewerCommand);
//# sourceMappingURL=ImageViewerCommand.js.map