var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var Stepper;
    (function (Stepper_1) {
        var Stepper = /** @class */ (function (_super) {
            __extends(Stepper, _super);
            function Stepper() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            Stepper.prototype.createContent = function () {
                var _this = this;
                Forguncy.Page.bind("pagedefaultdataloaded", this.pageNavigated.bind(this), "*");
                var self = this;
                var element = this.CellElement;
                var cellTypeMetaData = element.CellType;
                var container = $("<div id='" + this.ID + "'></div>");
                var div = $("<div class='ui-stepper-horizontal'></div>");
                var items = cellTypeMetaData.Items;
                items.forEach(function (item) { return item.Text = _this.getApplicationResource(item.Text); });
                for (var i = 0; i < items.length; i++) {
                    var div_step = $("<div class='ui-step' status=" + i + "></div>");
                    div_step.css("width", 100 / items.length + "%");
                    var div_number = $("<div class='ui-step-cont-number'><i></i><span>" + (i + 1) + "</span></div>");
                    var div_text = $("<div class='ui-step-cont-text' text='" + items[i].Text + "'>" + items[i].Text + "</div>");
                    div_step.append(div_number);
                    div_step.append(div_text);
                    var div_line_left = $("<div class='ui-step-line-left'></div>");
                    var div_line_right = $("<div class='ui-step-line-right'></div>");
                    div_step.append(div_line_left);
                    div_step.append(div_line_right);
                    //add commands
                    if (items[i].Commands) {
                        div_step.on("click", (function (commands, div_step) {
                            return function (e) {
                                if (div_step.hasClass("active") || div_step.hasClass("done")) {
                                    self.updateItemEditState($(div_step));
                                    self.executeCommand(commands);
                                }
                            };
                        })(items[i].Commands, div_step));
                        div_step.css("cursor", "pointer");
                    }
                    div.append(div_step);
                }
                this.onDependenceCellValueChanged(function (uiAction) {
                    self.updateItemsState();
                });
                container.append(div);
                return container;
            };
            Stepper.prototype.pageNavigated = function (arg1, arg2) {
                this.highlight(arg2.pageName);
            };
            Stepper.prototype.highlight = function (pageName) {
                var element = this.CellElement;
                var cellTypeMetaData = element.CellType;
                var items = cellTypeMetaData.Items;
                if (!items) {
                    return;
                }
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    if (this.hasCommandNavigateToPage(item.Commands, pageName)) {
                        //has highlight
                        if (Stepper.stepperStorage[pageName] && Stepper.stepperStorage[pageName][this.ID] && Stepper.stepperStorage[pageName][this.ID].editItem === i + "") {
                            return;
                        }
                        this.updateItemEditState($($("#" + this.ID).find(".ui-step")[i]));
                        return;
                    }
                }
            };
            Stepper.prototype.hasCommandNavigateToPage = function (commandList, pageName) {
                if (commandList && commandList.length > 0) {
                    for (var i = 0; i < commandList.length; i++) {
                        var command = commandList[i];
                        if (command && command["$type"] && command["$type"].indexOf("NavigateCommand") !== -1 && command.PageName === pageName) {
                            return true;
                        }
                    }
                }
                return false;
            };
            Stepper.prototype.updateItemEditState = function (stepDiv) {
                var pageName = this.getPageName();
                if (!Stepper.stepperStorage[pageName]) {
                    Stepper.stepperStorage[pageName] = {};
                }
                if (!Stepper.stepperStorage[pageName][this.ID]) {
                    Stepper.stepperStorage[pageName][this.ID] = {};
                }
                Stepper.stepperStorage[pageName][this.ID].editItem = stepDiv.attr("status");
                this.updateItemsState();
            };
            Stepper.prototype.getPageName = function () {
                return this.IsInMasterPage === true ? Forguncy.Page.getMasterPageName() : Forguncy.Page.getPageName();
            };
            Stepper.prototype.getActiveStateIndex = function () {
                var element = this.CellElement;
                var cellTypeMetaData = element.CellType;
                var items = cellTypeMetaData.Items;
                var activeItem = cellTypeMetaData.ActiveItem;
                var activeItemText;
                if (activeItem) {
                    activeItemText = this.evaluateFormula(activeItem);
                }
                if (activeItemText && typeof activeItemText === "string" && activeItemText.toLowerCase() === "all") {
                    return items.length + 1;
                }
                for (var i = 0; i < items.length; i++) {
                    if (items[i].Text === activeItemText) {
                        return i;
                    }
                }
                return 0;
            };
            Stepper.prototype.getEditIndex = function () {
                var pageName = this.getPageName();
                if (Stepper.stepperStorage[pageName] && Stepper.stepperStorage[pageName][this.ID]) {
                    return parseInt(Stepper.stepperStorage[pageName][this.ID].editItem);
                }
                return -1;
            };
            Stepper.prototype.updateItemsState = function () {
                var container = $("#" + this.ID);
                var div_steps = container.find(".ui-step");
                //clear all class
                div_steps.removeClass("active done edit");
                div_steps.find("i").removeClass("fa fa-pencil fa-check");
                var activeIndex = this.getActiveStateIndex();
                var editIndex = this.getEditIndex();
                if (editIndex === -1) {
                    editIndex = activeIndex;
                }
                //reset active/done/editable class
                for (var j = 0; j < div_steps.length; j++) {
                    var status_1 = parseInt($(div_steps[j]).attr("status"));
                    if (status_1 <= activeIndex) {
                        if (status_1 === editIndex) {
                            $(div_steps[j]).addClass("edit");
                            $(div_steps[j]).find("i").addClass("fa fa-pencil");
                        }
                        else if (status_1 === activeIndex) {
                            $(div_steps[j]).addClass("active");
                        }
                        else {
                            $(div_steps[j]).addClass("done");
                            $(div_steps[j]).find("i").addClass("fa fa-check");
                        }
                    }
                }
            };
            Stepper.prototype.getValueFromElement = function () {
                var element = this.CellElement;
                var cellTypeMetaData = element.CellType;
                var items = cellTypeMetaData.Items;
                var editIndex = this.getEditIndex();
                if (editIndex === -1) {
                    editIndex = this.getActiveStateIndex();
                }
                return items[editIndex].Text;
            };
            Stepper.prototype.setValueToElement = function (jelement, value) {
                var cellTypeMetaData = this.CellElement.CellType;
                var items = cellTypeMetaData.Items;
                for (var i = 0; i < items.length; i++) {
                    if (items[i].Text === value) {
                        this.updateItemEditState($($("#" + this.ID).find(".ui-step")[i]));
                        return;
                    }
                }
            };
            Stepper.prototype.setFontStyle = function (styleInfo) {
                var fontSize = 12;
                if (styleInfo.FontSize && styleInfo.FontSize > 0) {
                    fontSize = styleInfo.FontSize;
                }
                this.getContainer().find(".ui-stepper-horizontal .ui-step .ui-step-cont-text").css("font-size", fontSize);
                if (styleInfo.FontFamily) {
                    this.getContainer().find(".ui-stepper-horizontal .ui-step .ui-step-cont-text").css("font-family", styleInfo.FontFamily);
                }
                var color = "color: rgba(0,0,0,.26);";
                if (styleInfo.Foreground && styleInfo.Foreground !== "") {
                    if (Forguncy.ConvertToCssColor) {
                        color = Forguncy.ConvertToCssColor(styleInfo.Foreground);
                    }
                    else {
                        color = styleInfo.Foreground;
                    }
                }
                this.getContainer().find(".ui-stepper-horizontal .ui-step .ui-step-cont-text").css("color", color);
            };
            Stepper.prototype.onLoad = function () {
                this.updateItemsState();
            };
            Stepper.prototype.destroy = function () {
                Forguncy.Page.unbind("pagedefaultdataloaded", this.pageNavigated, "*");
            };
            Stepper.stepperStorage = {};
            return Stepper;
        }(Forguncy.Plugin.CellTypeBase));
        Stepper_1.Stepper = Stepper;
    })(Stepper = Forguncy.Stepper || (Forguncy.Stepper = {}));
})(Forguncy || (Forguncy = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CellTypeHelper.registerCellType("Stepper.StepperCellType, Stepper", Forguncy.Stepper.Stepper);
//# sourceMappingURL=Stepper.js.map